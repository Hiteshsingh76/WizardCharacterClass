
public class Wizard {
    private String name;
    private String house;
    private int mana;
    private int health;

    public Wizard(String name, String house, int mana, int health) {
        setName(name);
        setHouse(house);
        setMana(mana);
        setHealth(health);
    }

    public Wizard() {
        this.name = "Harry Potter";
        this.house = "Gryffindor";
        this.mana = 100;
        this.health = 100;
    }

    public void printStats(){
        System.out.println("Name: "+name);
        System.out.println("House: "+house);
        System.out.println("Mana: "+mana);
        System.out.println("Health: "+health);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(name.isEmpty())
        {
            System.out.println("Cant have a blank name, setting name to bob");
            this.name = "Bob the Wizard";
        }
        else{

            this.name = name;
        }

    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        switch(house)
        {
            case "Hufflepuff", "Slytherin", "Gryffindor", "Ravenclaw"->this.house=house;
            default-> this.house = "Hufflepuff";
        }
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        if(mana >=10 && mana <=25)
        {
            this.mana = mana;
        }
        else {
            System.out.println("Mana out of range, setting to 25");
            this.mana = 25;
        }
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health >= 75)
            this.health = health;
        else {
            System.out.println("Health too low, setting to 75");
            this.health = 75;
        }
    }
}
